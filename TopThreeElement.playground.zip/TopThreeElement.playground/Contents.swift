import UIKit

let arr = [10,8,6,3,2,9,5,1,7]
var max1 = Int()
var max2 = Int()
var max3 = Int()


for item in arr {
    if item > max1 {
        max3 = max2
        max2 = max1
        max1 = item
    } else if item > max2 {
        max3 = max2
        max2 = item
    } else if item > max3 {
        max3 = item
    }
}

print("Maximum element: ", max1)
print("Second Maximum element: ", max2)
print("Third Maximum element: ", max3)
